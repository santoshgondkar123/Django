from rest_framework import viewsets, permissions
from .models import User, Store, Rating
from .serializers import UserSerializer, StoreSerializer, RatingSerializer
from django.http import JsonResponse
from .permissions import IsSystemAdmin, IsStoreOwner

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all().order_by('id')
    serializer_class = UserSerializer
    permission_classes = [permissions.AllowAny] 



class StoreViewSet(viewsets.ModelViewSet):
    queryset = Store.objects.all().order_by('id')
    serializer_class = StoreSerializer
    permission_classes = [permissions.AllowAny]  



class RatingViewSet(viewsets.ModelViewSet):
    queryset = Rating.objects.all().order_by('-updated_at')
    serializer_class = RatingSerializer
    permission_classes = [permissions.AllowAny]  

def home(request):
    return JsonResponse({"message": "API Working", "status": "success"})


class AdminUserViewSet(viewsets.ModelViewSet):
    permission_classes = [IsSystemAdmin]  

class StoreViewSet(viewsets.ModelViewSet):
    def get_permissions(self):
        if self.action in ['create','update','partial_update','destroy']:
            return [IsSystemAdmin()]
        return [permissions.IsAuthenticated()]
class StoreViewSet(viewsets.ModelViewSet):
    queryset = Store.objects.all()   
    serializer_class = StoreSerializer
