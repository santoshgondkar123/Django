from django.db import models
from django.contrib.auth.models import AbstractUser


class User(AbstractUser):
    ROLE_CHOICES = [
        ('admin', 'System Administrator'),
        ('user', 'Normal User'),
        ('owner', 'Store Owner'),
    ]
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='user')
    address = models.CharField(max_length=400)

class Store(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="stores")
    name = models.CharField(max_length=100)
    email = models.EmailField()
    address = models.CharField(max_length=400)
    
    

    def average_rating(self):
        ratings = Rating.objects.filter(store=self)
        if ratings:
            return sum(r.value for r in ratings) / ratings.count()
        return 0

class Rating(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    store = models.ForeignKey(Store, on_delete=models.CASCADE)
    value = models.IntegerField()  
    updated_at = models.DateTimeField(auto_now=True)
