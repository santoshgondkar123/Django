from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import UserViewSet, StoreViewSet, RatingViewSet
from rest_framework.authtoken.views import obtain_auth_token

router = DefaultRouter()
router.register("users", UserViewSet)
router.register("stores", StoreViewSet)
router.register("ratings", RatingViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('api/login/', obtain_auth_token, name='api-login'), 

]
